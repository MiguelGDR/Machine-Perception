import numpy as np
from matplotlib import pyplot as plt
import math
import cv2
from UZ_utils import *
from a3_utils import *
from ex2_functions import *

# Creation of the accumulator array:
def hough_find_lines(I, rho_bins, theta_bins, threshold):
    h , w = I.shape

    max_rho = int(np.sqrt((h)**2 + (w)**2))
    accumulator = np.zeros((max_rho * 2, theta_bins))

    for x in range(h):
        for y in range(w):

            if I[x,y] >= threshold:
                for i in range(theta_bins):
                    theta = i * ((2*np.pi) / theta_bins)
                    rho = int(x * np.cos(theta) + y * np.sin(theta))
                    accumulator[rho + max_rho, i] += 1

    return accumulator

# Oneline
I = imread_gray('assignment3/images/bricks.jpg')
plt.subplot(1,3,1)
plt.imshow(I, cmap='gray')
plt.title('Image')

I = findedges(I,1,0.16)
plt.subplot(1,3,2)
plt.imshow(I, cmap='gray')  
plt.title('Edges')

plt.subplot(1,3,3)
plt.imshow(I)
accumulator = hough_find_lines(I,600,600,0.16)

top_10_lines = np.unravel_index(np.argsort(accumulator, axis=None)[-10:], accumulator.shape)

for i in range(10):
    rho, theta = top_10_lines[0][i], top_10_lines[1][i]
    draw_line(rho,theta,I.shape[0], I.shape[1])


plt.show()
