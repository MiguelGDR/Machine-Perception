import numpy as np
from matplotlib import pyplot as plt
import math
import cv2
from UZ_utils import *
from ex2_functions import *

# Creation of the accumulator array:
def hough_find_lines(I, theta_bins):
    h , w = I.shape

    max_rho = int(np.sqrt((h)**2 + (w)**2))
    accumulator = np.zeros((max_rho * 2, theta_bins))

    for x in range(h):
        for y in range(w):

            if I[x,y] != 0:
                for i in range(theta_bins):
                    theta = (i / theta_bins) * np.pi - np.pi/2
                    rho = int(x * np.cos(theta) + y * np.sin(theta))

                    accumulator[rho + max_rho, i] += 1

                plt.imshow(accumulator)
    return 

I = np.zeros((100,100))
I[10,10] = 1
I[10,20] = 1


theta_bins = 300
rho_bins = 300
plt.figure()
hough_find_lines(I,theta_bins)
plt.title('Synthetic')

# One line
I = imread_gray('assignment3/images/oneline.png')
I = findedges(I,1,0.16)
plt.figure()    
hough_find_lines(I,theta_bins)
plt.title('oneline.png')




plt.show()
