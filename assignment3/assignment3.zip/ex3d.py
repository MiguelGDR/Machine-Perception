import numpy as np
from matplotlib import pyplot as plt
import math
import cv2
from UZ_utils import *
from a3_utils import *
from ex2_functions import *

# Creation of the accumulator array:
def hough_find_lines(I, theta_bin):
    h , w = I.shape

    max_rho = int(np.sqrt((h)**2 + (w)**2))
    accumulator = np.zeros((max_rho * 2, theta_bins))

    for x in range(h):
        for y in range(w):
            if I[x,y] == 1:
                for i in range(theta_bins):
                    # Angle
                    theta = (i / theta_bins) * np.pi
                    # Rho
                    rho = int(x * np.cos(theta) - y * np.sin(theta))
                    accumulator[rho + max_rho, i] += 1

    return accumulator

def search_values(accumulator, threshold, I, theta_bins):
    # Size of the image
    h , w = I.shape
    max_rho = int(np.sqrt((h)**2 + (w)**2))

    for rho in range(accumulator.shape[0]):
        for theta in range(accumulator.shape[1]):
            if accumulator[rho,theta] >= threshold:
                print(theta)
                draw_line(rho - max_rho, (theta / theta_bins) * np.pi, h, w)

    return

I = np.zeros((100,100))
I[10,10] = 1
I[10,20] = 1

plt.imshow(I)
plt.title('Image')
theta_bins = 600
accumulator = hough_find_lines(I, theta_bins)

search_values(accumulator, 2, I, theta_bins)


plt.show()
