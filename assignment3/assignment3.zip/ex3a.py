import numpy as np
from matplotlib import pyplot as plt

# Creation of the accumulator array:
def incremenet_and_plot(accumulator, x, y):
    h , w = accumulator.shape

    max_rho = int(np.sqrt((h/2)**2 + (w/2)**2))

    # Theta and rho arrays for ploting
    t = np.linspace(0, 2 * np.pi, 300)
    r = x * np.cos(t) + y * np.sin(t)

    for i in range(w):
        theta = i * ((2*np.pi) / w)
        rho = int(x * np.cos(theta) + y * np.sin(theta))
        accumulator[rho + max_rho, i] += 1

    return accumulator
    

accumulator = np.zeros((600,600))
accumulator = incremenet_and_plot(accumulator, 10, 10)
plt.subplot(2,2,1)
plt.imshow(accumulator)

accumulator = np.zeros((600,600))
accumulator = incremenet_and_plot(accumulator, 30, 60)
plt.subplot(2,2,2)
plt.imshow(accumulator)

accumulator = np.zeros((600,600))
accumulator = incremenet_and_plot(accumulator, 50, 20)
plt.subplot(2,2,3)
plt.imshow(accumulator)

accumulator = np.zeros((600,600))
accumulator = incremenet_and_plot(accumulator, 80, 90)
plt.subplot(2,2,4)
plt.imshow(accumulator)


plt.show()